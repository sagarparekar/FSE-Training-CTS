package com.cts.demo;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.OptionalInt;
import java.util.Set;

public class RepeatedWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String input="long long time ago, in a galaxy far far away time";
		String[] splitStr=input.split(" ");
		
		List<String> words=Arrays.asList(splitStr);
		
		HashSet<String> uWord=new HashSet<>(words);
		
		for(String word:uWord) {
			if(Collections.frequency(words, word)>1) {
				System.out.println(" "+word+" ");
			}
		}
		
//		Set<Integer> repeated=new HashSet<>();
//		OptionalInt first=input.chars().filter(i->!repeated.add(i))
//				.findFirst();
//		if(first.isPresent()) {
//			System.out.println((char) first.getAsInt());
//		}
	}

}
