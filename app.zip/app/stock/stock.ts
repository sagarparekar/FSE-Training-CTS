export class Stock {

    transactionId:number|any;
    company_code_FK:number|any;
    stockPrice:number|any;
    timeStamp:string|any;
}
