import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Company } from './company';
import { CompanyService } from './company.service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  route: any;
  


  constructor(private companyService: CompanyService, private http: HttpClient) { }

  ngOnInit(): void {



    window.location.reload;
    this.getCompanyList();
    // this.companyObj.companyCode=this.route.snapshot.paramMap.get('id');

  }

  companyObj: Company = new Company();
  companyarr: Array<Company> = [];

  data: {} | any;

  editedCompany: any = {};

  addCompanyDetails() {
    this.companyService.addCompany(this.companyObj).subscribe(data => {
      this.data = JSON.stringify(data);
      this.companyarr.push(this.data);
      window.location.reload();
      console.log(this.companyarr);
    },
      error => {
        console.log(error);
      })
  }

  getCompanyList() {
    this.companyService.getAllCompanies().subscribe(data => {
      this.data = JSON.stringify(data);
      console.log(data);
      this.companyarr = Object.values(data);
      console.log(this.companyarr);
      window.location.reload;
    },
      error => {
        console.log(error);
      })
  }

  deleteCompany(cCode: number) {
    this.companyService.deleteCompany(cCode).subscribe(data => {
      let companyIndex = this.companyarr.findIndex(c => c.companyCode == cCode);
      this.companyarr.splice(companyIndex, 1);
      alert("company record deleted!");
      window.location.reload();
      this.getCompanyList();
    },
      error => {
        console.log(error);
      })
  }

  companym: Company = new Company();
  companyData: Array<Company> = [];
  response: any;
  getCompanyById(companyCode: number) {
    this.companyService.getCompanyBycode(companyCode).subscribe(data => {
      // this.data = JSON.stringify(data);
      console.log(data);
      // var arr = Object.keys(data).map(key => ({type: key, value: data[key]}));
      // console.log(arr);

      this.companyarr = Object.values(data);

      
      alert("Search result is given!" + this.companyData);
    })
  }


  updateCompany(companyObj: Company) {
    this.editedCompany = companyObj;
    this.companyService.getCompanyBycode(companyObj.companyCode).subscribe(
      (data) => {
        data.companyName = companyObj.companyName;
        data.ceoName = companyObj.ceoName;
        data.website = companyObj.website;
        data.stockExchange = companyObj.stockExchange;
        data.turnover = companyObj.turnover;
        this.companyService.updateCompany(companyObj, companyObj.companyCode).subscribe(
          (d) => {
            this.getCompanyList();
          },
          (error) => {
            console.log(error);
          })
      })

  }
}


