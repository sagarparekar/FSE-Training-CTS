import { Component, OnInit } from '@angular/core';

import { CompanyService } from '../company/company.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { StockService } from '../stock/stock.service';
import { Stock } from '../stock/stock';
import { Injectable, Pipe, PipeTransform } from '@angular/core';

@Component({
  selector: 'app-companydetails',
  templateUrl: './companydetails.component.html',
  styleUrls: ['./companydetails.component.css']
})


export class CompanydetailsComponent implements OnInit {
  stockdetails: any;

  constructor(private companyService: CompanyService, private route: ActivatedRoute, private stockService: StockService) { }

  AvgStockPrice: number | any;
  maxStockPrice: number | any;
  minStockPrice: number | any;
  stockList: Array<Stock> = [];
  companyDetails: any;
  idd: number | any;
  stockObj: Stock = new Stock();

  data: {} | any;
  ngOnInit(): void {

    this.route.params.subscribe(params => {
      let id = params['id'];
      this.companyDetails = this.companyService.getCompanyBycode(id).subscribe(
        data => {
          this.companyDetails = data;
          console.log("data is", this.companyDetails);
          this.getAvgStockPrice();
        }
      );
    })



  }


  getAvgStockPrice():void {
    let total = 0;

    let max = 0, min = this.companyDetails.stockList[0].stockPrice;
    for (let index = 0; index < this.companyDetails.stockList.length; index++) {
      const stockObj = this.companyDetails.stockList[index];

      if (stockObj.stockPrice > max) {
        max = stockObj.stockPrice;
        console.log("max"+max);
      }
      if (stockObj.stockPrice < min) {
        min = stockObj.stockPrice;
        console.log("min"+min);
      }
      total = total + stockObj.stockPrice;
      console.log("total"+total);
    }
    this.AvgStockPrice = total / this.companyDetails.stockList.length;
    this.maxStockPrice = max;
    this.minStockPrice = min;
    console.log("Avg stock"+this.AvgStockPrice);
  }

}
