import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyComponent } from './company/company.component';
import { CompanydetailsComponent } from './companydetails/companydetails.component';
import { StockComponent } from './stock/stock.component';

const routes: Routes = [
  {path:'', component:CompanyComponent},
  
  {path:'company/:id', component:CompanydetailsComponent},
  {path:'putstock/:id',component:StockComponent},
  {path:'getcompanybyid/:id',component:CompanyComponent},
  {path:'stockdata/:id',component:StockComponent}
  // {path:'company', component:CompanyComponent, 
  //     children:[{path:':id',component:CompanydetailsComponent}]
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
