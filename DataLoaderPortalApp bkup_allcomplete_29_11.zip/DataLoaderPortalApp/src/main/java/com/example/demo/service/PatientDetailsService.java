package com.example.demo.service;


import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.example.demo.exception.PatientDetailsException;
import com.example.demo.model.PatientDetails;

public interface PatientDetailsService {
	
	public List<PatientDetailsException>  savePatientDetails(MultipartFile excel);
	
	public PatientDetails getPatientByName(String patientName);
	
	public String updatePatientDetails(PatientDetails patientDetails);
}
