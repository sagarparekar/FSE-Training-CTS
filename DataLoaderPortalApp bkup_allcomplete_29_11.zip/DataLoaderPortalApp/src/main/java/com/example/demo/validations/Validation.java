package com.example.demo.validations;

import com.example.demo.model.PatientDetails;

public interface Validation {
	
	boolean isValid(PatientDetails patientDetails );

}
