package com.cts.test.JunitProject;

import java.util.Arrays;
import java.util.List;

public class FindFirst {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list=Arrays.asList(3,7,9,4,7);
		
	   FindFirst obj=new FindFirst();
	   System.out.println(obj.firstnum(list));
	}
	
	Integer firstnum(List<Integer> list) {
		
		Integer fNum=list.stream().findFirst().get();
		
		return fNum;
	}
	

}
