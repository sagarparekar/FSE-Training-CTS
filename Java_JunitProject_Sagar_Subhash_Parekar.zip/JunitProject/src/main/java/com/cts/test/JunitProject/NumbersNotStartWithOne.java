package com.cts.test.JunitProject;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NumbersNotStartWithOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> myList=Arrays.asList(11,15,45,78,13,115);
		NumbersNotStartWithOne obj=new NumbersNotStartWithOne();
		System.out.println(obj.numStartbyOne(myList));
	}
	
	List<String> numStartbyOne(List<Integer> myList){
		
		return myList.stream()
                .map(s -> s + "") // Convert integer to String
                .filter(s -> !s.startsWith("1")).collect(Collectors.toList());
                
	}

}
