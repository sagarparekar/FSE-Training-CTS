package com.cts.test.JunitProject;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SortingValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list = Arrays.asList(3, 7, 9, 3, 4, 7);
		SortingValues obj=new SortingValues();
		System.out.println(obj.sortByValue(list));
	}

	List<Integer> sortByValue(List<Integer> list) {
		
		List<Integer> sort=list.stream().sorted().collect(Collectors.toList());
		return sort;
		
	}
}
