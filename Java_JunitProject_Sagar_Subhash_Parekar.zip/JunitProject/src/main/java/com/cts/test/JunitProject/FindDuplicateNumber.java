package com.cts.test.JunitProject;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class FindDuplicateNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list=Arrays.asList(23,45,78,99,45,12,12);
		FindDuplicateNumber obj=new FindDuplicateNumber();
		System.out.println(obj.duplicateNum(list));
	}
	
	Set<Integer> duplicateNum(List<Integer> list) {
		
		Set<Integer> dNum=list.stream().filter(i->Collections.frequency(list, i)>1)
				.collect(Collectors.toSet());
		return dNum;
	}

}
