package com.cts.test.JunitProject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ConsucativeRepeatedWords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input = "a long long time ago, in a galaxy far far away time ";
		String[] splitStr = input.split(" ");

		List<String> listOfwords = Arrays.asList(splitStr);
		ConsucativeRepeatedWords obj = new ConsucativeRepeatedWords();
		System.out.println(obj.repeatedWords(listOfwords));
	}

	List<String> repeatedWords(List<String> listOfwords) {

		List<String> list = new ArrayList();

		for (int i = 0; i < listOfwords.size() - 1; i++) {
			if (listOfwords.get(i).equals(listOfwords.get(i + 1))) {

				list.add(listOfwords.get(i));
			}

		}
		return list;

	}
}
