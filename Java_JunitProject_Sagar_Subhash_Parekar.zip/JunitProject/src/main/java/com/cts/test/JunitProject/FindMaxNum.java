package com.cts.test.JunitProject;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class FindMaxNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list = Arrays.asList(3, 7, 9, 3, 4, 7);
		FindMaxNum obj = new FindMaxNum();
		System.out.println(obj.findMax(list));
	}

	long findMax(List<Integer> list) {

		long maxno = list.stream().max(Comparator.naturalOrder()).get();
		return maxno;

	}

}

//

//System.out.println();