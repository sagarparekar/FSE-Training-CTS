package com.cts.test.JunitProject;

import java.util.Arrays;
import java.util.List;

public class CountNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list=Arrays.asList(3,7,9,3,4,7);
		CountNum obj=new CountNum();
		
		System.out.println(obj.totalCount(list));
		
	}

	long totalCount(List<Integer> list) {
		long count=list.stream().count();
		return count;
	}
	
}
