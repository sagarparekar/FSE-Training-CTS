package com.cts.test.JunitProject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class NonRepeatedChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String input=" long long time ago in a galaxy far far away";
		NonRepeatedChar char1=new NonRepeatedChar();
		System.out.println(char1.nonRepeated(input));
	}

	Character nonRepeated(String input){
		Character result=input.chars()       
        .mapToObj(s -> Character.toLowerCase(Character.valueOf((char) s)))         
        .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting())) 
        .entrySet()
        .stream()
        .filter(entry -> entry.getValue() == 1L)
        .map(entry -> entry.getKey())
        .findFirst()
        .get();
		return result;
		
	}

	
}
