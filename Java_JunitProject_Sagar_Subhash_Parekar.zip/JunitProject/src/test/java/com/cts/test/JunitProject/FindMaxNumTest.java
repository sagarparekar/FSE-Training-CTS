package com.cts.test.JunitProject;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class FindMaxNumTest {

	@Test
	public void maxNum() {
		FindMaxNum obj=new FindMaxNum();
		
		long result=obj.findMax(Arrays.asList(3, 7, 9, 3, 4, 7));
		
		
		assertEquals(9, result);
		
	}
}
