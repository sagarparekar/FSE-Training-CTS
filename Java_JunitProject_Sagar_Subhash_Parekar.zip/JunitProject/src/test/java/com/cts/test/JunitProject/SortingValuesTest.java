package com.cts.test.JunitProject;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class SortingValuesTest {
	
	@Test
	public void sortedValue() {
		SortingValues obj=new SortingValues();
		
		List<Integer> result=obj.sortByValue(List.of(3, 7, 9, 3, 4, 7));
		
		List<Integer> expected=List.of(3, 3, 4, 7, 7, 9);
		
		assertTrue(result.size()==expected.size() && result.containsAll(expected) && expected.containsAll(result));
	}

}
