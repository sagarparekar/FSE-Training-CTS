package com.cts.test.JunitProject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class ConsucativeRepeatedWordsTest {

	@Test
	public void repeatWordTest() {
		ConsucativeRepeatedWords obj=new ConsucativeRepeatedWords();
		List<String> list = new ArrayList();
		String input = "a long long time ago, in a galaxy far far away time ";
		String[] splitStr = input.split(" ");

		List<String> listOfwords = Arrays.asList(splitStr);

		List<String> result=obj.repeatedWords(listOfwords);
		
		List<String> expected=Arrays.asList("long","far"); 
		
		assertTrue(result.size()==expected.size() && result.containsAll(expected) && expected.containsAll(result));
	}
}
