package com.cts.test.JunitProject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class EvenNumberTest {

	@Test
	public void evenTest() {

		EvenNumber obj1 = new EvenNumber();

		List<Integer> result = obj1.evennum(List.of(2, 3, 4, 5, 6, 7, 8, 9));
		List<Integer> expectedResult = List.of(2, 4, 6, 8);

		assertTrue(result.size() == expectedResult.size() && result.containsAll(expectedResult)
				&& expectedResult.containsAll(result));

	}

}
