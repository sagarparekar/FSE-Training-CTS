package com.cts.test.JunitProject;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.junit.Test;

public class FindDuplicateNumberTest {

	
@Test
public void checkDuplicate() {
	
	FindDuplicateNumber obj=new FindDuplicateNumber();
	
	Set<Integer> result=obj.duplicateNum(Arrays.asList(23,45,78,99,45,12,12));
	
	Set<Integer> expectedResult=Set.of(12,45);
	
	assertTrue(result.size()==expectedResult.size() && result.containsAll(expectedResult) && expectedResult.containsAll(result));
}

}
