package com.cts.test.JunitProject;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class NonRepeatedCharTest {

	@Test
	public void nonRepeatedChar() {
		NonRepeatedChar obj=new NonRepeatedChar();
		String input=" long long time ago in a galaxy far far away";
		Character Result=obj.nonRepeated(input);
		Character expected='t';
		
		assertTrue(Result==expected);
	}
}
