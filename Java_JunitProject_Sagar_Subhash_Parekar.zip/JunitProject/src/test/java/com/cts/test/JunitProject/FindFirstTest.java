package com.cts.test.JunitProject;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

public class FindFirstTest {
	
	@Test
	public void firstNumbertest() {
		FindFirst obj=new FindFirst();
		
		long result=obj.firstnum(Arrays.asList(3,7,9,4,7));
		
		assertEquals(3, result);
	}

}
