package com.cts.test.JunitProject;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class NumbersNotStartWithOneTest {
	
	@Test
	public void testNum() {
		NumbersNotStartWithOne obj=new NumbersNotStartWithOne();
		
		List<String> result=obj.numStartbyOne(Arrays.asList(11,15,45,78,13,115));
		
		List<Integer> expected=List.of(45,78);
		
		assertTrue(result.size()==expected.size() && result.containsAll(expected) && expected.containsAll(result));
	}

}
