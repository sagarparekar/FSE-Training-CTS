package com.cts.test.JunitProject;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

public class CountNumTest {
	
	@Test
	public void totalCounttest() {
		
		CountNum obj=new CountNum();
		
		long result=obj.totalCount(Arrays.asList(3,7,9,3,4,7));
		
		assertEquals(6, result);
		
	}

}
